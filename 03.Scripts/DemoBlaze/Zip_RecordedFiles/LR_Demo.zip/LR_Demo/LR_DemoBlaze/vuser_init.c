vuser_init()
{
	return 0;
}
