Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://edgedl.me.gvt1.com/edgedl/diffgen-puffin/hfnkpimlhhgieaddgfemjhofmfblmnib/b2f5a1549e528f9cddbf7a8057a9716d7b83ef011f061f44326e4b52cb63f933", "Referer=", ENDITEM, 
		LAST);

	/* enter store */

	lr_start_transaction("1_transaction");

	web_link("Enter the Store", 
		"Text=Enter the Store", 
		"Snapshot=t2.inf", 
		LAST);

	lr_think_time(10);

	lr_start_transaction("login");

	web_link("Sign In", 
		"Text=Sign In", 
		"Snapshot=t3.inf", 
		LAST);

	web_submit_form("Account.action", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=username", "Value=j2ee", ENDITEM, 
		"Name=password", "Value=j2ee", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	return 0;
}